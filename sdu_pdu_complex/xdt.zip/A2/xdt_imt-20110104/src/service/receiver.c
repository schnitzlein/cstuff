/**
  Gruppe 18
  Christoph Schwalbe
  Roman Kremmer

*/


/**
 * @file receiver.c
 * @ingroup service
 * @brief XDT layer receiver logic
 */

/**
 * @addtogroup service
 * @{
 */

#include "receiver.h"
#include "service.h"
#include <stdio.h>
enum
{
  last_pdu = pdu_msg_max_succ,
  tim
};

/** @brief connection number of data transfer */
static unsigned conn = 0;

XDT_timer rec_timer;
XDT_message msg;
/** @brief receiver states */
enum
{
  IDLE,
  AWAIT_CORRECT_DT,
  CONNECTED
};

/** @brief Flag indicating if we are already running, when entering the IDLE state */
static int running = 0;

/** @brief Current state */
static int state = IDLE;

/** @brief Current sequenz */
static int next_sequ = 1;


/** @brief Implements receiver's receive DT function */
void
receiver_receive_dt(XDT_pdu * pdu)
{
// daten umspeichern und als sdu weiterleiten (XDATind_1)
      XDT_sdu sdu_msg;
      sdu_msg.type = XDATind;
      sdu_msg.x.dat_ind.conn = conn;//Verbindungsnummer
      sdu_msg.x.dat_ind.sequ = pdu->x.dt.sequ;//Sequenznummer
      sdu_msg.x.dat_ind.eom = pdu->x.dt.eom;// kennzeichnet das letzte Paket
      XDT_COPY_DATA(pdu->x.dt.data, sdu_msg.x.dat_ind.data, pdu->x.dt.length);
      sdu_msg.x.dat_ind.length = pdu->x.dt.length;

      send_sdu(&sdu_msg);



      //abfrage, ob letztes packet
      if(pdu->x.dt.eom == 1){ 
	XDT_sdu last_sdu_msg;
	last_sdu_msg.type = XDISind;
	last_sdu_msg.x.dat_ind.conn = conn;
	send_sdu(&last_sdu_msg);
	//delete_timer(&rec_timer);
	
	//ack zurückballern
	XDT_pdu ack_msg;
	ack_msg.type = ACK;
	ack_msg.x.ack.code = ACK;
	ack_msg.x.ack.source_addr = pdu->x.dt.dest_addr; //absender wird neuer empfaenger
	ack_msg.x.ack.dest_addr = pdu->x.dt.source_addr;
	ack_msg.x.ack.conn = conn;
	ack_msg.x.ack.sequ =  pdu->x.dt.sequ;
      
	send_pdu(&ack_msg);
	
	// daten umspeichern und als sdu weiterleiten (XDATind_1)
	XDT_sdu sdu_msg;
	sdu_msg.type = XDATind;
	sdu_msg.x.dat_ind.conn = conn;//Verbindungsnummer
	sdu_msg.x.dat_ind.sequ = pdu->x.dt.sequ;//Sequenznummer
	sdu_msg.x.dat_ind.eom = pdu->x.dt.eom;// kennzeichnet das letzte Paket
	XDT_COPY_DATA(pdu->x.dt.data, sdu_msg.x.dat_ind.data, pdu->x.dt.length);
	sdu_msg.x.dat_ind.length = pdu->x.dt.length;

	send_sdu(&sdu_msg);

	state = IDLE;
	  
      } else {
		    
      //ack zurückballern
      XDT_pdu ack_msg;
      ack_msg.type = ACK;
      ack_msg.x.ack.code = ACK;
      ack_msg.x.ack.source_addr = pdu->x.dt.dest_addr; //absender wird neuer empfaenger
      ack_msg.x.ack.dest_addr = pdu->x.dt.source_addr;
      ack_msg.x.ack.conn = conn;
      ack_msg.x.ack.sequ =  pdu->x.dt.sequ;
      
      send_pdu(&ack_msg);
      
      }
}

/** @brief Implements the receiver's timeout handler */
void
receiver_timeout_handler(void)
{
//abo und xabortind rausfeuern
    
     //ABO machen
     XDT_pdu abo_msg;
     abo_msg.type = ABO;
     abo_msg.x.abo.code = ABO;
     abo_msg.x.abo.conn = conn;
     send_pdu(&abo_msg);
     //XABORTind nach oben
     XDT_sdu timeout_sdu_msg;
     timeout_sdu_msg.type = XABORTind;
     timeout_sdu_msg.x.dat_ind.conn = conn;
     send_sdu(&timeout_sdu_msg);
     delete_timer(&rec_timer);
	
     state = IDLE; 

}



/**
 * @brief Implements the receiver's IDLE state 
 *
 * When called first time, the #running flag is set and 
 * the state is switched to DATA_TRANSFER.
 * Also the first message get received and a ACK ist is send back to the sender.
 * When called second time, the #running flag is cleared.
 */
static void
receiver_idle(void)
{
  if (!running) {  //beim ersten aufruf wird der status auf running gesetzt, 
		   //und auf die erste pdu einer verbindung gewartet ,
		   //als sdu weiter geleitet und ein ACK zurückgeschickt
		   //und der timer wird erzeut und gestartet

    
    get_message(&msg); // hole eine nachricht aus der schlange

    //werte die nachricht aus wenn es eine pdu dt ist. sonst mache nichts
    if(msg.type == DT){
      XDT_pdu* pdu = (XDT_pdu*) &msg;      
      
      // daten umspeichern und als sdu weiterleiten (XDATind_1)
      XDT_sdu sdu_msg;
      sdu_msg.type = XDATind;
      sdu_msg.x.dat_ind.conn = conn;//Verbindungsnummer
      sdu_msg.x.dat_ind.sequ = pdu->x.dt.sequ;//Sequenznummer
      //next_sequ = sdu_msg.x.dat_ind.sequ; 
      sdu_msg.x.dat_ind.eom = pdu->x.dt.eom;// kennzeichnet das letzte Paket
      XDT_COPY_DATA(pdu->x.dt.data, sdu_msg.x.dat_ind.data, pdu->x.dt.length);
      sdu_msg.x.dat_ind.length = pdu->x.dt.length;

      send_sdu(&sdu_msg);
      
            
      //ack zurückballern
      XDT_pdu ack_msg;
      ack_msg.type = ACK;
      ack_msg.x.ack.code = ACK;
      ack_msg.x.ack.source_addr = pdu->x.dt.dest_addr; //absender wird neuer empfaenger
      ack_msg.x.ack.dest_addr = pdu->x.dt.source_addr;
      ack_msg.x.ack.conn = conn;
      ack_msg.x.ack.sequ =  pdu->x.dt.sequ;
      
      send_pdu(&ack_msg);
            
      create_timer(&rec_timer, tim);
      set_timer(&rec_timer, 10); //setze mit 10 sec timeout
      
      next_sequ++;
      running = 1;
      //printf("idle->CONNECTED\n");
      state = CONNECTED;
    }
      
  } else { // beim wechsel vom betrieb auf idle wird run_receiver verlassen
      running = 0;
      delete_timer(&rec_timer);
    }
  
}


/** @brief Implements the receiver's CONNECTED state */
void
receiver_connected(void)
{

  
  get_message(&msg);
  
  //timeout
  if(msg.type == tim){
    receiver_timeout_handler();

  }

  if(msg.type == DT){
    XDT_pdu* pdu = (XDT_pdu*) &msg; 
//printf("will seqNr %d haben\n",next_sequ);
    //wenn die sequenznummer richtig ist : normale verarbeitung
    if(pdu->x.dt.sequ <= next_sequ){
      
      receiver_receive_dt(&msg);
      //sequenz nummer erhöhen
      next_sequ++;
//printf("bleibe im state, da alles dufte\n");

    } else { // wenn sequenznummer nicht richtig : packet verwerfen und zustand wechseln
        //printf("connected->WAIT_CORRECT_DT\n");
      set_timer(&rec_timer, 10); //setze mit 10 sec timeout
	state = AWAIT_CORRECT_DT;

    
    }
  }

  //wenn tim kommt wieder idlen  
  if (msg.type == tim){
    receiver_timeout_handler();
  }

      
}

/** @brief Implements the receiver's await_correct_dt state */
void
receiver_await_correct_dt(void)
{ 
  get_message(&msg);
 

  //verarbeite neues DT
  if(msg.type == DT ){
	  XDT_pdu* pdu = (XDT_pdu*) &msg;
	// wenn wieder korrektes packet -> zustand nach connected und packet auch auswerten,ack zurück und auch prüfen ob letztes paket
	//kleinere DTs bestätigen	  
	  if (pdu->x.dt.sequ < next_sequ){
	    receiver_receive_dt(&msg);  //packet auswerten und bearbeiten
       set_timer(&rec_timer,10);
	  } 
	  //richtige sequenznr erhalten
	  if (pdu->x.dt.sequ == next_sequ){
		//fehlendes Datenpaket erhalten?
                //printf("await_correct_dt->AWAIT_CORRECT_DT\n");
                receiver_receive_dt(&msg);  //packet auswerten und bearbeiten
                set_timer(&rec_timer,10);
		state = CONNECTED;
		
	  } else {
		 state = AWAIT_CORRECT_DT;
	  }
  }

  //timeout
  if(msg.type == tim){
    receiver_timeout_handler();

  }

}         


/** 
 * @brief State scheduler
 *
 * Calls the appropriate function associated with the current protocol state.
 */
void
run_receiver(void)
{
    
  do {
    switch (state) {
    case IDLE:
      receiver_idle();
      break;
    case AWAIT_CORRECT_DT:
	receiver_await_correct_dt();
	break;
    case CONNECTED:
	receiver_connected();
	break;
    }
  } while (running);

} /* run_receiver */

/**
 * @brief Receiver instance entry function
 *
 * After the dispatcher has set up a new receiver instance
 * and established a message queue between both processes
 * this function is called to process the messages available
 * in the message queue.
 * The only functions and macros needed here are:
 * - get_message() to read SDU, PDU and timer messages from the queue,
 * - send_sdu() to send an SDU message to the consumer,
 * - send_pdu() to send a PDU message to the sending peer,
 * - #XDT_COPY_DATA to copy the message payload,
 * - create_timer() to create a timer associated with a message type,
 * - set_timer() to arm a timer (on expiration a timer associated message is
 *               put into the queue),
 * - reset_timer() to disarm a timer (all timer associated messages are removed
 *                 from the queue)
 * - delete_timer() to delete a timer.
 *
 * @param connection the connection number assigned to the data transfer
 *        handled by this instance
 */
void start_receiver(unsigned connection)
{
  conn = connection;
     
  run_receiver();
} /* start_receiver */


/**
 * @}
 */
