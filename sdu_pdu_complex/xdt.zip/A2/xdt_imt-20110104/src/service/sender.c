/**
  Gruppe 18
  Christoph Schwalbe
  Roman Kremmer

*/


/**
 * @file sender.c
 * @ingroup service
 * @brief XDT layer sender logic
 */

/**
 * @addtogroup service
 * @{
 */

#include "sender.h"
#include "service.h"
#include <stdio.h>

#define MAX 2 // maximale puffergröße


/** @brief connection number of data transfer */
static unsigned conn = 0;

XDT_timer to_t2_timer;
XDT_timer to_t1_timer;
XDT_timer to_t3_timer;
XDT_message msg;
/** @brief receiver states */
enum
{
  IDLE,
  CONNECTED,
  AWAIT_ACK,
  GO_BACK_N,
  BREAK
};

enum
{
  last_pdu = pdu_msg_max_succ,
  to_t1, //verbindungsaufbau timer //12
  to_t2, //gobackN timer
  to_t3 // timer für gesammte verbindungsdauer, ohne das was geschieht
};

/** @brief Flag indicating if we are already running, when entering the IDLE state */
static int running = 0;

/** @brief Current state */
static int state = IDLE;

/** @brief Buffer for DATA Packages, save data */
static XDT_pdu buffer[MAX];
static int input = 0;

/** @brief Return value of error or non error */
static int retval = 0;

/** @brief last acknowlege Sequenznummer */
static unsigned int sequenznr = 0;

static unsigned int last_seq = 0; // seq vom eom -packet
static unsigned int oldest_seq = 0; // erstes gepufferte packet
static unsigned int newest_seq = 0; // letztes verschicktes und gepuffertes packet
static unsigned int break_seq = 0;
static unsigned int c = 0;
/**
 * @brief Implements the sender's IDLE state 
 *
 * When called first time, the #running flag is set,
 * the first message is send and 
 * the state is switched to AWAIT_ACK.
 * When called second time, the #running flag is cleared.
 */

void
sender_idle(void)
{
  if (!running) {
    running = 1;
    state = AWAIT_ACK;
    
    get_message(&msg);

    if(msg.type == XDATrequ){
      XDT_sdu* sdu = (XDT_sdu*) &msg;

      //sdu weiterleiten
      
      XDT_pdu pdu_msg;
      pdu_msg.type = DT;
      pdu_msg.x.dt.code = DT;
      pdu_msg.x.dt.source_addr = sdu->x.dat_requ.source_addr;
      pdu_msg.x.dt.dest_addr = sdu->x.dat_requ.dest_addr;
      pdu_msg.x.dt.conn = sdu->x.dat_requ.conn;
      pdu_msg.x.dt.sequ = sdu->x.dat_requ.sequ;
      pdu_msg.x.dt.eom = sdu->x.dat_requ.eom;
      XDT_COPY_DATA(sdu->x.dat_requ.data, pdu_msg.x.dt.data,sdu->x.dat_requ.length);//data       sdu->x.dat_requ.data
      pdu_msg.x.dt.length = sdu->x.dat_requ.length;
      
      sequenznr = sdu->x.dat_requ.sequ;	//sequenznummer aus sdu ziehen
      //DT in Warteschlange speichern
      last_seq = (last_seq++)%MAX;
      buffer[last_seq] = pdu_msg;

      send_pdu(&pdu_msg);
      
      //verbindung herstellen timer
      create_timer(&to_t1_timer, to_t1);
      set_timer(&to_t1_timer, 10); //setze mit 10 sec timeout 
      
    }
    
  } else {

    running = 0;
    
  }
}

/** @brief Implements the sender's AWAIT_ACK state */
void
sender_await_ack(void)
{
  get_message(&msg);
 
  //erwarte das ACK, sende sdu bestätigung und lösche den timer
  //gehe zu state Connected über
  if(msg.type == ACK){
    XDT_pdu* pdu = (XDT_pdu*) &msg;
    XDT_sdu sdu_msg;
    sdu_msg.type = XDATconf;
    sdu_msg.x.dat_conf.conn = pdu->x.ack.conn;
    sdu_msg.x.dat_conf.sequ = pdu->x.ack.sequ;

    send_sdu(&sdu_msg);
    
    //timer 1 löschen (auch aus warteschlange)
    reset_timer(&to_t1_timer);
    delete_timer(&to_t1_timer);
    
    //Timer 2 (fürs gobackN) starten
    create_timer(&to_t2_timer, to_t2);
    set_timer(&to_t2_timer, 2); //setze mit 1 sec timeout    

    //Timer 3 (für gesammte verbindung) starten
    create_timer(&to_t3_timer, to_t3);
    set_timer(&to_t3_timer, 10); //setze mit 10 sec timeout
    
    state = CONNECTED;    
  }
  //timeout
  //gehe zu state IDLE
  if(msg.type == to_t1){
    XDT_sdu timeout_sdu_msg;
    timeout_sdu_msg.type = XABORTind;
    timeout_sdu_msg.x.dat_ind.conn = conn;
    send_sdu(&timeout_sdu_msg);
    delete_timer(&to_t1_timer);


    state = IDLE;
  } 
}

/** @brief Implements the consumer's CONNECT state */
void
sender_connected(void)
{	 
  get_message(&msg);

  //ABO
  if (msg.type == ABO)
  {
     XDT_sdu abo_sdu_msg;
     abo_sdu_msg.type = XABORTind;
     abo_sdu_msg.x.dat_ind.conn = conn;
     send_sdu(&abo_sdu_msg);
     reset_timer(&to_t3_timer);
	
     state = IDLE; 
  }

  //timeout
  if (msg.type == to_t3)
  {
     XDT_sdu timeout_sdu_msg;
     timeout_sdu_msg.type = XABORTind;
     timeout_sdu_msg.x.dat_ind.conn = conn;
     send_sdu(&timeout_sdu_msg);
     reset_timer(&to_t3_timer);

     state = IDLE;
  }

  if (msg.type == ACK){
    
    XDT_pdu* pdu = (XDT_pdu*) &msg;

    set_timer(&to_t2_timer, 2); //timer neusetzen für den nächsten ACK
    set_timer(&to_t3_timer, 10);

    oldest_seq = (pdu->x.ack.sequ + 1)%MAX;


    //letzte ACK (ACK_L)
    if(pdu->x.ack.sequ == last_seq){
      XDT_sdu last_sdu_msg;
      last_sdu_msg.type = XDISind;
      last_sdu_msg.x.dis_ind.conn = conn;
     // printf("LAST ACK erhalten und sende last ack sdu\n");
      send_sdu(&last_sdu_msg);
      
      state = IDLE;    
    } else {

      state = CONNECTED; 
    }
  }
  
  //sende DT   XDATrequ -> state = CONNECTED
  if (msg.type == XDATrequ)
  {
      XDT_sdu* sdu = (XDT_sdu*) &msg;
    
      //sdu weiterleiten
      XDT_pdu pdu_msg;
      pdu_msg.type = DT;
      pdu_msg.x.dt.code = DT;
      pdu_msg.x.dt.source_addr = sdu->x.dat_requ.source_addr;
      pdu_msg.x.dt.dest_addr = sdu->x.dat_requ.dest_addr;
      pdu_msg.x.dt.conn = sdu->x.dat_requ.conn;
      pdu_msg.x.dt.sequ = sdu->x.dat_requ.sequ;
      pdu_msg.x.dt.eom = sdu->x.dat_requ.eom;
      XDT_COPY_DATA(sdu->x.dat_requ.data, pdu_msg.x.dt.data,sdu->x.dat_requ.length);//data       sdu->x.dat_requ.data
      pdu_msg.x.dt.length = sdu->x.dat_requ.length;
      

      
      //dt in buffer packen
      newest_seq = (pdu_msg.x.dt.sequ)%MAX;
      buffer[newest_seq] = pdu_msg;
      send_pdu(&pdu_msg);
    
      // wenn letztes packet -> sequenznummer merken um später den letzen ACK zu identifizieren
      if (sdu->x.dat_requ.eom == 1){
	last_seq = sdu->x.dat_requ.sequ; 
      }
      
      //wenn puffer voll, im break warten bis wieder platz
      if ((newest_seq)%MAX == (oldest_seq%MAX)){ 
	//xBREAKind
	XDT_sdu sdu_msg;
	sdu_msg.type = XBREAKind;
	sdu_msg.x.break_ind.conn = sdu->x.dat_requ.conn;

	send_sdu(&sdu_msg);
        break_seq = pdu_msg.x.dt.sequ ;
	state = BREAK; 
      } else
      {
      
	//xdat conf
	XDT_sdu sdu_msg;
	sdu_msg.type = XDATconf;
	sdu_msg.x.dat_conf.conn = sdu->x.dat_requ.conn;
	sdu_msg.x.dat_conf.sequ = sdu->x.dat_requ.sequ;

	send_sdu(&sdu_msg);
	state = CONNECTED; 
      }
	
  }//XDATrequ
  
  //timeout2
  if(msg.type == to_t2){
    //reset_timer(&to_t2_timer);
    printf("connected->GO_BACK_N\n");
    c=2;
    state = GO_BACK_N;
  }
  
}


/** @brief Implements the senders's BREAK state */
void
sender_break(void)
{

  printf("BIN IM BREAK\n");
  get_message(&msg);

  //ACK go_back_n Paket
  if (msg.type == ACK)
  {  
    XDT_pdu* pdu = (XDT_pdu*) &msg;
    XDT_sdu sdu_msg;
    sdu_msg.type = XDATconf;
    sdu_msg.x.dat_conf.conn = pdu->x.ack.conn;
    sdu_msg.x.dat_conf.sequ = break_seq;				;

    send_sdu(&sdu_msg);  
    set_timer(&to_t2_timer, 2); //timer neusetzen für den nächsten ACK
    set_timer(&to_t3_timer, 10);
    oldest_seq = (pdu->x.ack.sequ + 1)%MAX;
    



    //letzte ACK (ACK_L)
    if(pdu->x.ack.sequ == last_seq){
      XDT_sdu last_sdu_msg;
      last_sdu_msg.type = XDISind;
      last_sdu_msg.x.dis_ind.conn = conn;
      //printf("LAST ACK erhalten und sende last ack sdu\n");
      send_sdu(&last_sdu_msg);
      //printf("break->IDLE\n");
      state = IDLE;    
    } else {
      //printf("break->CONNECTED\n");
      state = CONNECTED; 
    } 
  }

  //timeout2
  if (msg.type == to_t2){
    reset_timer(&to_t2_timer);
    //delete_timer(&to_t2_timer);

    //printf("break->GO_BACK_N\n");
    c=3;
    state = GO_BACK_N;
  }


  //timeout3
  if (msg.type == to_t3){
     XDT_sdu timer_sdu_msg;
     timer_sdu_msg.type = XABORTind;
     timer_sdu_msg.x.dat_ind.conn = conn;
     send_sdu(&timer_sdu_msg);
	
     reset_timer(&to_t3_timer);
     delete_timer(&to_t3_timer);
     state = IDLE; 	
  }
 

  //ABO/XABORTind
  if (msg.type == ABO)
  {
     XDT_sdu abo_sdu_msg;
     abo_sdu_msg.type = XABORTind;
     abo_sdu_msg.x.dat_ind.conn = conn;
     send_sdu(&abo_sdu_msg);

     reset_timer(&to_t3_timer);
     delete_timer(&to_t3_timer);	
     state = IDLE; 
  }
 
}

/** @brief Implements the senders's GO_BACK_N state */
void
sender_go_back_n(void)
{
//printf("xxxxxxBIN IM go_back_N\n");

  /* versendetet alle gepufferten packete ab dem zuletzt bestätigten neu
  */
  int i;
  for(i = oldest_seq%MAX ; i<= newest_seq%MAX ; i++){
    //alle gepufferten packete rausfeuern
    send_pdu(&buffer[i]);
//printf("schicke packet  %d\n",i);

  }
  
  // statuswechsel
  // wenn vom break gekommen -> wieder nach break. sonst nach connected
  if (c=3){ 
    printf("go_back_an -> BREAK\n");
    state = BREAK; 
  } else { //c=2
    set_timer(&to_t2_timer, 2); // gobackN timer wieder an
    printf("go_back_an -> CONNECTED\n");
    state = CONNECTED;
  }

  
}

/** 
 * @brief State scheduler
 *
 * Calls the appropriate function associated with the current protocol state.
 */
static void
run_sender(void)
{
  
  do {
    switch (state) {
    case IDLE:
      sender_idle();
      break;
    case CONNECTED:
      sender_connected();
      break;
    case AWAIT_ACK:
      sender_await_ack();
      break;
    case GO_BACK_N:
      sender_go_back_n();
      break;
    case BREAK:
      sender_break();
      break;
    }
  } while (running);
    
} /* run_sender */

/** 
 * @brief Sender instance entry function
 *
 * After the dispatcher has set up a new sender instance
 * and established a message queue between both processes
 * this function is called to process the messages available
 * in the message queue.
 * The only functions and macros needed here are:
 * - get_message() to read SDU, PDU and timer messages from the queue,
 * - send_sdu() to send an SDU message to the producer,
 * - send_pdu() to send a PDU message to the receiving peer,
 * - #XDT_COPY_DATA to copy the message payload,
 * - create_timer() to create a timer associated with a message type,
 * - set_timer() to arm a timer (on expiration a timer associated message is
 *               put into the queue),
 * - reset_timer() to disarm a timer (all timer associated messages are
 *                 removed from the queue),
 * - delete_timer() to delete a timer.
 */
void start_sender(void)
{  
  run_sender();
} /* start_sender */





/**
 * @}
 */
