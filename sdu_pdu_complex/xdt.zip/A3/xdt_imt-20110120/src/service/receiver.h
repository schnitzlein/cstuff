/**
 * @file receiver.h
 * @ingroup service
 * @brief XDT layer receiver's entry point
 */

#ifndef RECEIVER_H
#define RECEIVER_H

/**
 * @addtogroup service
 * @{
 */

static void receiver_idle(void);
void receiver_connected(void);
void receiver_await_correct_dt(void);
void run_receiver(void);
void start_receiver(unsigned connection);



/**
 * @}
 */

#endif /* RECEIVER_H */
