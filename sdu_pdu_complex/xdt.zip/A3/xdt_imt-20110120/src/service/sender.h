/**
 * @file sender.h
 * @ingroup service
 * @brief XDT layer sender's entry point
 */

#ifndef SENDER_H
#define SENDER_H

/**
 * @addtogroup service
 * @{
 */


void sender_await_ack(void);
void sender_idle(void);
void sender_connected(void);
void sender_break(void);
void sender_go_back_n(void);
static void run_sender(void);
void start_sender(void);
void start_sender(void);


/**
 * @}
 */

#endif /* SENDER_H */
