/**
 * @file service.h
 * @ingroup service
 * @brief XDT layer convenient routines
 */

#ifndef SERVICE_H
#define SERVICE_H

/**
 * @addtogroup service
 * @{
 */


#include "pdu.h"
#include "queue.h"
#include "errors.h"

#include <xdt/address.h>
#include <xdt/sdu.h>
#include <xdt/timer.h>


/** @brief Type of the service instance set up by the dispatcher */
typedef enum
{
  XDT_SERVICE_NA, /**< not an instance  */
  XDT_SERVICE_SENDER, /**< sender instance */
  XDT_SERVICE_RECEIVER /**< receiver instance */
} XDT_role;

XDT_role dispatch(XDT_address const *sap, unsigned *c, XDT_error error_case);


/** @brief Message structure to use, when reading from an XDT queue */
typedef struct
{
  long type; /**< type of message (specific PDU, SDU or timer type) */
  char data[(sizeof (XDT_sdu) > sizeof (XDT_pdu) ? sizeof (XDT_sdu) : sizeof (XDT_pdu)) - sizeof (long)]; /**< buffer for holding the message data */
} XDT_message;

void send_pdu(XDT_pdu * pdu);
void send_sdu(XDT_sdu * sdu);
void get_message(XDT_message * msg);
void create_timer(XDT_timer * timer, int type);
void set_timer(XDT_timer * timer, double timeout);
void reset_timer(XDT_timer * timer);
void delete_timer(XDT_timer * timer);


/**
 * @}
 */

#endif /* SERVICE_H */
