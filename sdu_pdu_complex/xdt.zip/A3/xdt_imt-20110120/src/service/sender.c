/**
  Gruppe 18
  Christoph Schwalbe
  Roman Kremmer

*/


/**
 * @file sender.c
 * @ingroup service
 * @brief XDT layer sender logic
 */

/**
 * @addtogroup service
 * @{
 */

#include "sender.h"
#include "service.h"
#include <stdio.h>

// maximale puffergröße
#define MAX 1024

// timer zeiten
#define TO_T1_TIME 10
#define TO_T2_TIME 1
#define TO_T3_TIME 5

// startwert des überlfensters
#define CGWND_START 1 
#define SSTHRESLD_START 768

/** @brief connection number of data transfer */
static unsigned conn = 0;

XDT_timer to_t2_timer;
XDT_timer to_t1_timer;
XDT_timer to_t3_timer;
XDT_message msg;
/** @brief receiver states */
enum
{
  IDLE,
  CONNECTED,
  AWAIT_ACK,
  GO_BACK_N,
  GO_BACK_N_WAIT_FOR_ACK,
  BREAK
};
/*  -go back N kann jetzt nicht alle gepufferten packete auf einmal verschicken,
     sondern nur noch soviel, wie das überlastfenster es zulässt
    -go back N wait for ACK gibt die möglichkeit während des go back N platz
     im überlastfenster freizugeben, indem es auf ein ACK wartet
    -wenn im go back N wait for ACK eine XDTrequ empfangen wird, wird deren inhalt
     im sendepuffer des goBackN gespeichert und dort rausgeschickt. das XDTconf wird
     erst beim verlassen des goBackN nach connected verschickt.(ob diese nötig ist,
     wird in einer zusätlichen flag-variable markiert)
    -sobald go back N alle gepufferten packete verschickt hat, wechselt der
     zustand wieder nach connected, wo die restlichen ACKs emfangen werden können
     
    -in den BREAK zustand, kommt man jetzt auch wenn das überlastfenster ausgeschöpft
     wurde
*/

/** @brief slow start states */
enum
{
  EXPONENTIAL,
  LINEAR
};
/*  -das slow start state gibt die wachstumsphase des überlastfensters an.
    -bei jedem ACK wird abhängig vom status das cgwnd entsprechend der phase erhöht.
    -bei ACK-timeopt to_2 wird das cgwnd auf den ausgangswert gesetzt und der thresld angepasst
    -Zustandsänderung : beim start :exponential
			erreichen des thresld : exponential -> linear
			timeout to_2 : linear-> exponential
*/

enum
{
  last_pdu = pdu_msg_max_succ,
  to_t1, //verbindungsaufbau timer //12
  to_t2, //gobackN timer
  to_t3 // timer für gesammte verbindungsdauer, ohne das was geschieht
};

/** @brief Flag indicating if we are already running, when entering the IDLE state */
static int running = 0;

/** @brief Current state */
static int state = IDLE;

/** @brief Current slow start state */
static int slow_start = EXPONENTIAL;

/** @brief Buffer for DATA Packages, save data */
static XDT_pdu buffer[MAX];

/** @brief Return value of error or non error */
static int retval = 0;

static unsigned int last_seq = 0; // seq vom eom -packet
static unsigned int oldest_seq = 0; // erstes gepufferte packet
static unsigned int newest_seq = 0; // letztes verschicktes und gepuffertes packet
static unsigned int break_seq = 0; 
static unsigned int c = 0; // zustand, aus dem nach gobackN gewechselt wurde

static unsigned int gobackN_seq = 0; //sequenznummer, welches im gobackN verschickt werden soll ( alle drunter alle zwischen dieser und dem oldest_seq wurden durch das gobackN bereits verschickt, aber noch nicht durch ein ACK bestätigt.
static unsigned int to_conf_DT = 0; //flag, ob im gobackNwaitforACK ein DTreq bekommen wurde, was noch confirmed werden muss
static unsigned int to_conf_DT_seq = 0; //sequenznummer des ausstehenden confs 
static unsigned int cgwnd_used = 0; //aktuell genutzter platz im überlastfesnter
static float  cgwnd = CGWND_START; //aktuelle größe des überlastfensters
static unsigned int ssthresld = SSTHRESLD_START;

void
received_ACK() //verhalten des slow start algorithmus, nach erhalten einer ACK
{
  cgwnd_used--;
  
  if(cgwnd<MAX){ // überlast an der senderpuffergröße beschränken 
    if(slow_start == EXPONENTIAL){
      cgwnd = cgwnd + 1;
    } else {
      cgwnd = cgwnd + (1/cgwnd);
    }
  }
  if(cgwnd>=ssthresld){
    slow_start = LINEAR;
    printf("->LINEAR\n");
  }


  printf("--cqwnd_used %d \n",cgwnd_used);
  printf("+cgwnd %f\n",cgwnd);
  printf("ssthresld %d\n",ssthresld);

}

void
DT_sended() //verhalten des slow start algorithmus, nach versenden einer DT
{
  cgwnd_used++;
  printf("++cqwnd_used %d \n",cgwnd_used);
  printf("cgwnd %f\n",cgwnd);
  printf("ssthresld %d\n",ssthresld);
}

void
lost_ACK()
{
  
  cgwnd_used = 0;
  ssthresld = cgwnd / 2;
  cgwnd = CGWND_START;
  printf("->EXPONENTIAL\n");
  slow_start = EXPONENTIAL;

}

/** 3 überstehenden funktionen sind nur für die funktionalität des slow_start_automaten,*/

/**
 * @brief Implements the sender's IDLE state 
 *
 * When called first time, the #running flag is set,
 * the first message is send and 
 * the state is switched to AWAIT_ACK.
 * When called second time, the #running flag is cleared.
 */

void
sender_idle(void)
{
  if (!running) {
    running = 1;
    state = AWAIT_ACK;
    
    get_message(&msg);

    if(msg.type == XDATrequ){
      XDT_sdu* sdu = (XDT_sdu*) &msg;

      //sdu weiterleiten
      
      XDT_pdu pdu_msg;
      pdu_msg.type = DT;
      pdu_msg.x.dt.code = DT;
      pdu_msg.x.dt.source_addr = sdu->x.dat_requ.source_addr;
      pdu_msg.x.dt.dest_addr = sdu->x.dat_requ.dest_addr;
      pdu_msg.x.dt.conn = sdu->x.dat_requ.conn;
      conn = sdu->x.dat_requ.conn;
      pdu_msg.x.dt.sequ = sdu->x.dat_requ.sequ;
      pdu_msg.x.dt.eom = sdu->x.dat_requ.eom;
      XDT_COPY_DATA(sdu->x.dat_requ.data, pdu_msg.x.dt.data,sdu->x.dat_requ.length);
      pdu_msg.x.dt.length = sdu->x.dat_requ.length;
      
      
      newest_seq = (pdu_msg.x.dt.sequ)%MAX;
      buffer[newest_seq] = pdu_msg;
      send_pdu(&pdu_msg);
      DT_sended();
      //verbindung herstellen timer
      create_timer(&to_t1_timer, to_t1);
      set_timer(&to_t1_timer, TO_T1_TIME);
      
    }
    
  } else {

    running = 0;
    
  }
}

/** @brief Implements the sender's AWAIT_ACK state */
void
sender_await_ack(void)
{
  get_message(&msg);
 printf("..im await ACK\n");
  //erwarte das ACK, sende sdu bestätigung und lösche den timer
  //gehe zu state Connected über
  if(msg.type == ACK){
    received_ACK();
    XDT_pdu* pdu = (XDT_pdu*) &msg;
    XDT_sdu sdu_msg;
    sdu_msg.type = XDATconf;
    sdu_msg.x.dat_conf.conn = pdu->x.ack.conn;
    sdu_msg.x.dat_conf.sequ = pdu->x.ack.sequ;

    send_sdu(&sdu_msg);
 
    oldest_seq = (pdu->x.ack.sequ + 1)%MAX;
    
    //timer 1 löschen (auch aus warteschlange)
    reset_timer(&to_t1_timer);
    delete_timer(&to_t1_timer);
    
    //Timer 2 (fürs gobackN) starten
    create_timer(&to_t2_timer, to_t2);
    set_timer(&to_t2_timer, TO_T2_TIME); //setze mit 1 sec timeout    

    //Timer 3 (für gesammte verbindung) starten
    create_timer(&to_t3_timer, to_t3);
    set_timer(&to_t3_timer, TO_T3_TIME); //setze mit 10 sec timeout
    printf("await_rack->CONNECTED\n");
    state = CONNECTED;    
  }
  //timeout
  //gehe zu state IDLE
  if(msg.type == to_t1){
    XDT_sdu timeout_sdu_msg;
    timeout_sdu_msg.type = XABORTind;
    timeout_sdu_msg.x.dat_ind.conn = conn;
    send_sdu(&timeout_sdu_msg);
    delete_timer(&to_t1_timer);


    state = IDLE;
  } 
}

/** @brief Implements the consumer's CONNECT state */
void
sender_connected(void)
{	 
  printf("im connected\n");
  get_message(&msg);

  //ABO
  if (msg.type == ABO)
  {
     XDT_sdu abo_sdu_msg;
     abo_sdu_msg.type = XABORTind;
     abo_sdu_msg.x.dat_ind.conn = conn;
     send_sdu(&abo_sdu_msg);
	
     state = IDLE; 
  }

  //timeout
  if (msg.type == to_t3)
  {
     XDT_sdu timeout_sdu_msg;
     timeout_sdu_msg.type = XABORTind;
     timeout_sdu_msg.x.dat_ind.conn = conn;
     send_sdu(&timeout_sdu_msg);
     reset_timer(&to_t3_timer);

     state = IDLE;
  }

  if (msg.type == ACK){
    received_ACK();
    
    XDT_pdu* pdu = (XDT_pdu*) &msg;

    set_timer(&to_t2_timer, TO_T2_TIME); //timer neusetzen für den nächsten ACK
    set_timer(&to_t3_timer, TO_T3_TIME);

    oldest_seq = (pdu->x.ack.sequ + 1)%MAX;


    //letzte ACK (ACK_L)
    if(pdu->x.ack.sequ == last_seq){
      XDT_sdu last_sdu_msg;
      last_sdu_msg.type = XDISind;
      last_sdu_msg.x.dis_ind.conn = conn;
     // printf("LAST ACK erhalten und sende last ack sdu\n");
      send_sdu(&last_sdu_msg);
      
      state = IDLE;    
    } else {

      state = CONNECTED; 
    }
  }
  
  //sende DT   XDATrequ -> state = CONNECTED
  if (msg.type == XDATrequ)
  {
      XDT_sdu* sdu = (XDT_sdu*) &msg;
    
      //sdu weiterleiten
      XDT_pdu pdu_msg;
      pdu_msg.type = DT;
      pdu_msg.x.dt.code = DT;
      pdu_msg.x.dt.source_addr = sdu->x.dat_requ.source_addr;
      pdu_msg.x.dt.dest_addr = sdu->x.dat_requ.dest_addr;
      pdu_msg.x.dt.conn = sdu->x.dat_requ.conn;
      pdu_msg.x.dt.sequ = sdu->x.dat_requ.sequ;
      pdu_msg.x.dt.eom = sdu->x.dat_requ.eom;
      XDT_COPY_DATA(sdu->x.dat_requ.data, pdu_msg.x.dt.data,sdu->x.dat_requ.length);//data       sdu->x.dat_requ.data
      pdu_msg.x.dt.length = sdu->x.dat_requ.length;
      

      
      //dt in buffer packen
      newest_seq = (pdu_msg.x.dt.sequ)%MAX;
      buffer[newest_seq] = pdu_msg;
      send_pdu(&pdu_msg);
      DT_sended();
      // wenn letztes packet -> sequenznummer merken um später den letzen ACK zu identifizieren
      if (sdu->x.dat_requ.eom == 1){
	last_seq = sdu->x.dat_requ.sequ; 
      }

      if ((cgwnd_used+1 > cgwnd)||((newest_seq+2)%MAX == (oldest_seq%MAX))){  // wenn überlastfenster ausgeschöpft oder puffer voll,-> im break auf ACK warten, bis wieder platz
	//xBREAKind
	/*XDT_sdu sdu_msg;
	sdu_msg.type = XBREAKind;
	sdu_msg.x.break_ind.conn = sdu->x.dat_requ.conn;

	send_sdu(&sdu_msg);*/
        break_seq = pdu_msg.x.dt.sequ ;
	printf("connected->BREAK\n");
	state = BREAK; 
      } else
      {
      
	//xdat conf
	XDT_sdu sdu_msg;
	sdu_msg.type = XDATconf;
	sdu_msg.x.dat_conf.conn = sdu->x.dat_requ.conn;
	sdu_msg.x.dat_conf.sequ = sdu->x.dat_requ.sequ;

	send_sdu(&sdu_msg);
 	
	state = CONNECTED; 
      }
	
  }//XDATrequ
  
  //timeout2
  if(msg.type == to_t2){
    
    // XDT-break;
    /*XDT_sdu sdu_msg;
    sdu_msg.type = XBREAKind;
    sdu_msg.x.break_ind.conn = conn;
    send_sdu(&sdu_msg);*/
    
    set_timer(&to_t2_timer, TO_T2_TIME);
    gobackN_seq = oldest_seq;
    c=2;
    state = GO_BACK_N;
    lost_ACK();
  }
  
}


/** @brief Implements the senders's BREAK state */
void
sender_break(void)
{
  get_message(&msg);

  //ACK go_back_n Paket
  if (msg.type == ACK)
  { 
    received_ACK();
    XDT_pdu* pdu = (XDT_pdu*) &msg;
    XDT_sdu sdu_msg;
    sdu_msg.type = XDATconf;
    sdu_msg.x.dat_conf.conn = pdu->x.ack.conn;
    sdu_msg.x.dat_conf.sequ = break_seq;

    send_sdu(&sdu_msg);  
    set_timer(&to_t2_timer, TO_T2_TIME); //timer neusetzen für den nächsten ACK
    set_timer(&to_t3_timer, TO_T3_TIME);
    oldest_seq = (pdu->x.ack.sequ + 1)%MAX;
    

    //letzte ACK (ACK_L)
    if(pdu->x.ack.sequ == last_seq){
      XDT_sdu last_sdu_msg;
      last_sdu_msg.type = XDISind;
      last_sdu_msg.x.dis_ind.conn = conn;
      //printf("LAST ACK erhalten und sende last ack sdu\n");
      send_sdu(&last_sdu_msg);
      //printf("break->IDLE\n");
      state = IDLE;    
    } else {
      printf("break->CONNECTED\n");
      state = CONNECTED; 
    } 
  }

  //timeout2
  if (msg.type == to_t2){

    printf("break->GOBACKN\n");
    c=3;
    set_timer(&to_t2_timer, TO_T2_TIME);
    gobackN_seq = oldest_seq;

    state = GO_BACK_N;
    lost_ACK();
  }


  //timeout3
  if (msg.type == to_t3){
     XDT_sdu timer_sdu_msg;
     timer_sdu_msg.type = XABORTind;
     timer_sdu_msg.x.dat_ind.conn = conn;
     send_sdu(&timer_sdu_msg);
	
     reset_timer(&to_t3_timer);
     delete_timer(&to_t3_timer);
     state = IDLE; 	
  }
 

  //ABO/XABORTind
  if (msg.type == ABO)
  {
     XDT_sdu abo_sdu_msg;
     abo_sdu_msg.type = XABORTind;
     abo_sdu_msg.x.dat_ind.conn = conn;
     send_sdu(&abo_sdu_msg);

     reset_timer(&to_t3_timer);
     delete_timer(&to_t3_timer);	
     state = IDLE; 
  }
 
}

/** @brief Implements the senders's GO_BACK_N state */
void
sender_go_back_n(void)
{
  /* versendetet alle gepufferten packete ab dem zuletzt bestätigten neu
  */
        printf("cqwnd_used %d \n",cgwnd_used);
      printf("cgwnd %f\n",cgwnd);
  int i;
  for(i = gobackN_seq%MAX ; i<= newest_seq%MAX ; i++){
    
    //alle gepufferten packete raussenden, solange fenstergröße es zulässt
    if(cgwnd_used+1 <= cgwnd){

      send_pdu(&buffer[i]);
      gobackN_seq++;
      DT_sended();
      //printf("schicke packet  %d\n",i);
    }

  }
  
  // wenn fertig statuswechsel nach connected. sonst nach GO_BACK_N_WAIT_FOR_ACK
  // wenn vom break gekommen -> wieder nach break. sonst nach connected
//   printf("wenn gobackN_seq:%d == newest_seq%d -> dann zurück nach c\n",gobackN_seq,newest_seq);
  if((gobackN_seq-1)%MAX == newest_seq%MAX){
 
    if(c==2){ // wenn aus connected gekommen

// wenn im gbNwfACK ein req , dann hier ein conf

  if (to_conf_DT == 1){
    XDT_sdu sdu_msg;
    sdu_msg.type = XDATconf;
    sdu_msg.x.dat_conf.conn = conn;
    sdu_msg.x.dat_conf.sequ = to_conf_DT_seq;
    
    send_sdu(&sdu_msg);
    to_conf_DT = 0 ;
  }

      set_timer(&to_t2_timer, TO_T2_TIME); // gobackN timer wieder an
      printf("go_back_an -> CONNECTED\n");
      state = CONNECTED;
    
    }
  
    if(c==3){ // wenn aus gobackN gekommen
      printf("go_back_an -> BREAK\n");
      state = BREAK;
  
    }
  
    
  } else { //c==2
    printf("go_back_an -> GO_BACK_N_WAIT_FOR_ACK\n");
    state= GO_BACK_N_WAIT_FOR_ACK;
  }

  
}


/** @brief Implements the senders's GO_BACK_N_WAIT_FOR_ACK state */
void
sender_go_back_n_wait_for_ack(void)
{
  get_message(&msg);

  if (msg.type == XDATrequ)
  { 
    //wenn noch ein XDATrequ statt nem ACK kommt, wird dass packet ans ende des gobackN puffers gepackt aber hier nicht versendet
    //und erst beim zustandswechsel gobackN->CONNECTED  confirmed
    
      XDT_sdu* sdu = (XDT_sdu*) &msg;
    
      XDT_pdu pdu_msg;
      pdu_msg.type = DT;
      pdu_msg.x.dt.code = DT;
      pdu_msg.x.dt.source_addr = sdu->x.dat_requ.source_addr;
      pdu_msg.x.dt.dest_addr = sdu->x.dat_requ.dest_addr;
      pdu_msg.x.dt.conn = sdu->x.dat_requ.conn;
      pdu_msg.x.dt.sequ = sdu->x.dat_requ.sequ;
      pdu_msg.x.dt.eom = sdu->x.dat_requ.eom;
      XDT_COPY_DATA(sdu->x.dat_requ.data, pdu_msg.x.dt.data,sdu->x.dat_requ.length);
      pdu_msg.x.dt.length = sdu->x.dat_requ.length;
      
      //dt in buffer packen
      newest_seq = (pdu_msg.x.dt.sequ)%MAX;
      buffer[newest_seq] = pdu_msg;
      
      to_conf_DT = 1 ;
      to_conf_DT_seq = sdu->x.dat_requ.sequ; 
      
      // wenn letztes packet -> sequenznummer merken um später den letzen ACK zu identifizieren
      if (sdu->x.dat_requ.eom == 1){
	last_seq = sdu->x.dat_requ.sequ; 
      }
      
    printf("im gobackNwaitforack ein DTrequ erhalten\n");
  }

  if (msg.type == ACK)
  { 
    printf("im gobackNwaitforack ein ACK erhalten\n");
    received_ACK();
    XDT_pdu* pdu = (XDT_pdu*) &msg; 

    set_timer(&to_t2_timer, TO_T2_TIME);
    set_timer(&to_t3_timer, TO_T3_TIME);
    oldest_seq = (pdu->x.ack.sequ + 1)%MAX;
    



    //prüfe ob letztes ACK (ACK_L)->ende  sonst ->zurück nach gonackN
    if(pdu->x.ack.sequ == last_seq){
      XDT_sdu last_sdu_msg;
      last_sdu_msg.type = XDISind;
      last_sdu_msg.x.dis_ind.conn = conn;
      //printf("LAST ACK erhalten und sende last ack sdu\n");
      send_sdu(&last_sdu_msg);
      printf("break->IDLE\n");
      state = IDLE;    
    } else {
      printf("gobackNwaitforack->GOBACKN\n");
      state = GO_BACK_N; 
    } 
  }

  //timeout2
  if (msg.type == to_t2){
    gobackN_seq = oldest_seq; //wenn hier ein timeout, muss das gobackN "von forn beginnen" ab dem ersten nicht bestätigem packet
    cgwnd_used = 0;
    set_timer(&to_t2_timer,TO_T2_TIME);
    printf("gobackNwaitforack->GOBACKN wegen timeout\n");
    state = GO_BACK_N; 
  }
  
  //timeout3
  if (msg.type == to_t3){
      XDT_sdu timer_sdu_msg;
      timer_sdu_msg.type = XABORTind;
      timer_sdu_msg.x.dat_ind.conn = conn;
      send_sdu(&timer_sdu_msg);
	
      reset_timer(&to_t3_timer);
      delete_timer(&to_t3_timer);
      state = IDLE; 	
  }


  //ABO/XABORTind
  if (msg.type == ABO)
  {
      XDT_sdu abo_sdu_msg;
      abo_sdu_msg.type = XABORTind;
      abo_sdu_msg.x.dat_ind.conn = conn;
      send_sdu(&abo_sdu_msg);

      reset_timer(&to_t3_timer);
      delete_timer(&to_t3_timer);	
      state = IDLE;
  }

  
}



/** 
 * @brief State scheduler
 *
 * Calls the appropriate function associated with the current protocol state.
 */
static void
run_sender(void)
{
  
  do {
    switch (state) {
    case IDLE:
      sender_idle();
      break;
    case CONNECTED:
      sender_connected();
      break;
    case AWAIT_ACK:
      sender_await_ack();
      break;
    case GO_BACK_N:
      sender_go_back_n();
      break;
    case GO_BACK_N_WAIT_FOR_ACK:
      sender_go_back_n_wait_for_ack();
      break;
    case BREAK:
      sender_break();
      break;
    }
  } while (running);
    
} /* run_sender */

/** 
 * @brief Sender instance entry function
 *
 * After the dispatcher has set up a new sender instance
 * and established a message queue between both processes
 * this function is called to process the messages available
 * in the message queue.
 * The only functions and macros needed here are:
 * - get_message() to read SDU, PDU and timer messages from the queue,
 * - send_sdu() to send an SDU message to the producer,
 * - send_pdu() to send a PDU message to the receiving peer,
 * - #XDT_COPY_DATA to copy the message payload,
 * - create_timer() to create a timer associated with a message type,
 * - set_timer() to arm a timer (on expiration a timer associated message is
 *               put into the queue),
 * - reset_timer() to disarm a timer (all timer associated messages are
 *                 removed from the queue),
 * - delete_timer() to delete a timer.
 */
void start_sender(void)
{  
  run_sender();
} /* start_sender */





/**
 * @}
 */
